function setup() {
	createCanvas(680, 220);
	background(52, 73, 94);

	;
}

function draw() {
	if (mouseIsPressed){
		fill(50, 0);
	}else{
		fill(255, 50);
	}
	ellipse(mouseX, mouseY, 80, 80);
}


